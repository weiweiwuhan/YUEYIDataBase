﻿Bossard 本地采集工具修复包 2.0.1（2026-11-12）

修复：缺少 Playwright 或浏览器启动失败时，旧工具只导出缓存却返回退出码0。
现在显示具体错误、失败阶段和本次 Python 对应的安装命令，返回1；新增图片统计。

更新方法：
1. 结束正在运行的采集窗口。
2. 将本包 BossardCollector 文件夹内的文件复制到你原来的 BossardCollector 中，覆盖同名程序文件。
3. 本包不含 cache、settings.bat、collector_config.json、output 或审核 Excel；不要删除你原来的这些文件和文件夹。
4. 双击原目录的 01_install.bat，在 settings.bat 指定的同一 Python 环境中安装依赖和 Chromium。
5. 安装成功后运行 03_images_only.bat，首行应显示2.0.1，并看到“补采主图 BNxxx”的进度。

也可在原工具目录打开命令提示符执行（按本机路径替换Python）：
"C:\ProgramData\Anaconda3\python.exe" -m pip install -r collector_requirements.txt
"C:\ProgramData\Anaconda3\python.exe" -m playwright install chromium

本次新下载为0、只有391条产品和1张示例图时，不代表主图已经采集完成。请查看控制台和cache/crawl-report.json。
Python流程与缺依赖回归在Linux测试，Windows入口需在你本机运行确认。
