# Bossard 本地采集工具包2.0（2026-11-12）

先阅读 BOSSARD_COLLECTOR_GUIDE.md（也有“本地采集操作说明.txt”），再读 BOSSARD_COLLECTOR_API.md 学习函数和数据接口。

1. 完整解压到可写目录，不要在压缩包内运行。
2. 修改 settings.bat 中的 COLLECTOR_PYTHON，指向 Python3.10+ 的 python.exe。
3. 运行 01_install.bat 安装独立依赖与浏览器。
4. 运行 03_images_only.bat 给已有产品补图；02_resume_with_images.bat 则继续采集新产品和照片。
5. output 目录生成新的时间戳 Excel；cache/images 保存原始响应文件和 PNG。
6. 日常参数修改 collector_config.json，解释与示例见教程第4节；04_export_offline.bat 不联网重新导出。

附39个分类、391个产品属性的旧快照和317个待续采BN；BN2示例主图已实测下载，其余390个主图待补采。全部记录仍待审核，分类归属仅为候选，尚未完成全量，不会自动写入业务库。图片目前只辅助本地审核，不会经Excel自动进入业务图片库。

遇403/429、验证码或robots禁止时停止并保留断点；请查看采集报告。Windows启动文件已提供，未在实际Windows电脑上运行验证；Python流程、主图下载与完整解压包离线导出在Linux中验证。
