# Bossard 2026-11-11 采集交付

## 本轮实际结果

- 已发现分类节点：39；已发现BN候选：708；已导出BN详情：391；待续采：317。
- 共浏览39个分类页面状态、100次“加载更多”，读取5个公开sitemap。
- 采集器检测到HTTP403后停止，未绕过访问限制。报告不能确定403的上游根因，不据此声称网络配置再次失效。
- 产品单位为BN系列，不是逐尺寸SKU。不是Bossard全站完整目录。
- 391条均保留公开属性、来源URL、抓取时间、原始属性JSON、缺失字段。
- 当前没有通过明确面包屑或已验证产品列表确认的产品分类关系；分类编号为空，候选单独列出。普通链接可能来自推荐区域，必须人工核实。
- 有一个末级分类未显示产品链接（segment-clamping-bolts），可能为空类或动态加载问题，见采集报告。
- 全部产品保持“待审核”，未向业务库写入任何记录。

## 审核与导入

先检查来源页面、原始属性和缺失字段。需要归类的产品请先人工核实并填写“分类编号”，不能直接把候选全部当成正确分类。确认后只将通过的分类、产品标为“是”，在网站“紧固件目录 → 导入已审核 Excel”先预览，再确认写入。保留未确认项为“待审核”或“否”。

## 续采

仅在网站访问恢复、允许采集的网络环境使用。不要为了继续采集绕过403、验证码或robots规则。先保留本缓存。安装依赖：

```sh
python -m pip install -r collector_requirements.txt
python -m playwright install chromium
```

解压后在本目录执行以下命令，复用cache内已读取的391个系列，不要加--refresh，以免重复抓取已完成产品。默认分类仍使用已有检查点：

```sh
python bossard_catalog.py --categories categories.json --crawl --cache cache --delay 3 --output Bossard_续采_待审核.xlsx
```

再次遇到403/429会停止并记录原因，不要连续重试。若已有系统Chrome，可使用--browser-executable指定可执行文件。

## 离线重新导出

```sh
python bossard_catalog.py --categories categories.json --products 采集数据.json --output Bossard_离线重新导出.xlsx
```

缓存只用于续采和重复导出，不代表官网内容没有变化。请勿覆盖已经人工审核的Excel。
