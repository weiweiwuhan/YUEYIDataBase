"""Run from the lab directory: python -m factory_agent_lab init."""

import argparse
import json
from pathlib import Path
import sys

from .core import Lab, LabError, Conflict
from .scenarios import backup, run_scenario


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="工业质量Agent离线教学实验包；全部默认数据为合成资料，不能视为现场结果。"
    )
    parser.add_argument("--workspace", default="lab_workspace")
    parser.add_argument(
        "--role",
        choices=["viewer", "engineer", "admin"],
        default="engineer",
        help="仅模拟可信会话角色；不是生产认证",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("init")
    tool = sub.add_parser("tool")
    tool.add_argument("name")
    tool.add_argument("--args-file", required=True)
    agent = sub.add_parser("agent")
    agent.add_argument("--question", required=True)
    agent.add_argument("--backend", choices=["mock", "deepseek"], default="mock")
    sub.add_parser("evaluate")
    scenario = sub.add_parser("scenario")
    scenario.add_argument("--name", required=True)
    sub.add_parser("backup")
    sub.add_parser("report")
    args = parser.parse_args(argv)
    try:
        lab = Lab(args.workspace, args.role)
        if args.command == "init":
            result = lab.init()
        elif args.command == "tool":
            path = Path(args.args_file)
            if path.stat().st_size > 65536:
                raise LabError("参数文件超过64KB")
            payload = json.loads(path.read_text(encoding="utf-8-sig"))
            result = lab.tool(args.name, payload)
        elif args.command == "agent":
            result = lab.agent(args.question, args.backend)
        elif args.command == "evaluate":
            result = lab.evaluate()
        elif args.command == "scenario":
            result = run_scenario(args.name)
        elif args.command == "backup":
            result = backup(lab)
        else:
            result = lab.report()
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        return 0 if result.get("passed", True) is not False else 2
    except (LabError, PermissionError, OSError, ValueError, KeyError) as exc:
        print(
            json.dumps(
                {"error": str(exc), "type": type(exc).__name__, "status": "blocked"},
                ensure_ascii=False,
            ),
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
