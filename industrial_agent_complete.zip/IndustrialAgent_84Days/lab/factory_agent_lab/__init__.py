"""Offline-first factory quality Agent teaching lab. Not production control software."""
__version__ = '1.0.0'
