# 工业质量 Agent 离线实验包

这是《从视觉 AI 到工业 Agent：84 天实战手册》的配套教学工程，版本 1.0.0。它使用 Python 3.10 或以上的标准库，不要求安装 PyTorch、向量数据库、Web 框架或第三方 Agent 框架。默认不联网、不调用付费模型、不读取你的公司数据库。

**所有工位、批次、模型报告、知识和数值均为合成教学资料。** CLI 中的 `--role` 只是模拟可信会话角色，不是生产登录认证。它不接入 MES、QMS、PLC 或产线放行；`approved` 也只改变本地教学记录。

## 1. 第一次运行

将完整 `lab` 文件夹复制到你控制的目录。例如 Windows PowerShell：

```powershell
Set-Location "F:\IndustrialAgentLab"
python --version
python -m factory_agent_lab init
python -m factory_agent_lab tool get_station_snapshot --args-file lab_workspace/args/station.json
python -m factory_agent_lab agent --question "ST-01工位B-002批次误报为什么升高" --backend mock
python -m factory_agent_lab evaluate
python -m unittest discover -s tests -v
```

如果本机 Python 命令不是 `python`，可以用你实际的 Python 3.10+ 可执行文件替换。命令必须从包含 `factory_agent_lab` 文件夹的 `lab` 根目录运行。中文重定向有编码问题时可先设置进程环境变量 `PYTHONUTF8=1`。

`init` 创建默认 `lab_workspace`，并生成参数文件。它不会重置你已经修改的数据库记录，也不会覆盖已经存在的参数文件；需要全新实验时使用新的工作目录，不要删除未备份数据。

```powershell
python -m factory_agent_lab --workspace lab_workspace_second init
python -m factory_agent_lab --workspace lab_workspace_second tool get_batch_metrics --args-file lab_workspace_second/args/batch.json
```

`--workspace` 和 `--role` 是全局参数，放在 `init/tool/agent/...` 子命令之前。

## 2. 文件和输出

```text
lab/
  factory_agent_lab/
    core.py          # 合成数据、有限工具、校验、权限、工作单和审计
    provider.py      # 可选DeepSeek只读工具循环，默认不调用
    scenarios.py     # 隔离故障演练、一致备份
    __main__.py      # CLI入口
  tests/test_lab.py  # 离线测试，不发网络请求
  lab_workspace/     # 首次init后生成，不属于生产数据
    factory.sqlite3  # SQLite业务记录、审计和运行日志
    args/            # UTF-8 JSON参数例子
    runs/            # Agent每次运行记录
    evaluation.json  # 离线固定案例评测结果
    report.json      # 本地审计摘要
    manifest.json    # 合成资料与版本说明
    backups/         # 一致SQLite快照ZIP
```

`source/editorial_contract.md` 是教材编辑用契约，不是运行依赖。读者只需这个完整 `lab` 文件夹。代码中记录的 UTC 时间带时区；工厂事件与本地显示需要另外按照部署要求转换。

## 3. 合成数据定义

工位 `ST-01` 对应螺钉 `P-SCREW-01`。TP表示真实NG且判NG；FN表示真实NG却判OK；FP表示真实OK却判NG；TN表示真实OK且判OK。

| 批次 | TP | FN | FP | TN | NG数 | OK数 | 漏检率FN/NG | 误报率FP/OK |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| B-001 | 96 | 4 | 18 | 882 | 100 | 900 | 4% | 2% |
| B-002 | 92 | 8 | 90 | 810 | 100 | 900 | 8% | 10% |

这些是图片级OK/NG计数，不是像素IoU、真实工厂统计或长期良率。NG或OK分母为零时，相关率返回JSON `null`，不能将未知写成0%。

合成变更中，曝光从8000微秒变成5000微秒，亮度从40变成70，两项同时变更。查询到变化只能提出候选原因，不能证明哪一项造成误报。模型评估报告 `R-BASE` 和 `R-CAND` 属于同一 `DS-01`：基线TP95/FN5/FP12/TN288，候选TP97/FN3/FP9/TN291；均为100个NG和300个OK。`R-OTHER` 使用不同数据集，比较工具会拒绝直接排名。

## 4. 工具接口

参数JSON Schema见同目录 `TOOL_SCHEMAS.json`；运行时由 `validate_args` 执行标准库校验，不要求额外安装JSON Schema库。所有参数文件为JSON对象。缺失字段、未知字段、类型不符、无时区时间和越界ID会拒绝；SQL查询使用参数绑定。不要把数据库口令、真实个人信息或API密钥写入参数文件。

| 工具 | 参数 | 角色 |
|---|---|---|
| get_station_snapshot | station_id | viewer/engineer/admin |
| get_batch_metrics | batch_id | 同上 |
| get_recent_changes | station_id、since（带时区ISO8601） | 同上 |
| compare_runs | baseline_run_id、candidate_run_id | 同上 |
| search_knowledge | query、可选product_id | 同上；只检索business、reviewed、未删除条目 |
| draft_work_order | station_id、batch_id、summary、idempotency_key | engineer/admin，显式人工CLI调用 |
| update_work_order | work_order_id、expected_version、summary | engineer/admin，显式人工CLI调用 |
| approve_work_order | work_order_id、expected_version | admin，显式人工CLI调用 |

模型后端只获得前五个只读工具，即使CLI角色为admin，也不能让模型调用写入或批准。`search_knowledge` 在计算匹配分数前执行资料权限、审核、删除与产品范围过滤。它是简单词面匹配的教学基线，不是向量检索，也不能验证复杂语义。

常用命令：

```powershell
python -m factory_agent_lab tool get_batch_metrics --args-file lab_workspace/args/batch.json
python -m factory_agent_lab tool get_recent_changes --args-file lab_workspace/args/changes.json
python -m factory_agent_lab tool compare_runs --args-file lab_workspace/args/compare.json
python -m factory_agent_lab tool search_knowledge --args-file lab_workspace/args/search.json
python -m factory_agent_lab report
```

`source`、`documents.id`、版本和内容摘要是追溯依据。审计只记录参数及结果摘要、工具、角色、状态和运行ID，不把API密钥写入日志。运行记录包含问题和工具输出，因此迁移到真实业务时仍需脱敏、保留期限和访问控制。

## 5. 工单与审批实验

初始化生成 `draft.json`、`update.json` 和 `approve.json`。在一个全新工作目录中，第一张工单通常为ID 1；如果已有数据，请以创建结果中的 `work_order.id` 和 `version` 修改参数文件。

```powershell
python -m factory_agent_lab tool draft_work_order --args-file lab_workspace/args/draft.json
python -m factory_agent_lab tool draft_work_order --args-file lab_workspace/args/draft.json
python -m factory_agent_lab --role admin tool approve_work_order --args-file lab_workspace/args/approve.json
python -m factory_agent_lab tool update_work_order --args-file lab_workspace/args/update.json
```

同一幂等键和同一请求载荷返回同一个工单，不重复创建；同键不同载荷报冲突。审批来自模拟admin会话，参数不能自报批准人。批准记录绑定工单ID、版本和载荷SHA-256。修改后版本增加、状态回到draft，原批准失效。旧版本批准再次提交将被拒绝；要批准新版本，必须重新核对新内容，并更新参数中的 `expected_version`。

这只是本地记录审批，不会提交真实工单、改变设备参数或放行产品。生产系统需要真实身份认证、职责分离、工单权限、批准有效期、可靠消息、跨系统状态核对与审计设计；教学中的CLI角色不是安全边界。

## 6. 故障演练与评测

```powershell
python -m factory_agent_lab scenario --name missing_data
python -m factory_agent_lab scenario --name prompt_injection
python -m factory_agent_lab scenario --name stale_approval
python -m factory_agent_lab scenario --name duplicate_write
python -m factory_agent_lab scenario --name timeout
python -m factory_agent_lab scenario --name permission
python -m factory_agent_lab scenario --name incompatible_runs
```

每个 `scenario` 创建并清理独立临时工作目录，不修改你的默认实验记录。最终版本会返回结构化 `evidence`，目录清理后仍可保存标准输出作为观察记录：`duplicate_write`包括工单ID、同载荷调用次数、冲突请求次数和最终工单数；`stale_approval`包括批准前后版本、载荷摘要、批准有效性与旧请求拒绝原因。这些字段来自该次临时数据库操作；时间到期没有在此场景验证。`timeout` 通过故障注入演示两次有界只读重试，不真实等待网络，也不能证明写入重试正确。`prompt_injection` 在工具资料中加入恶意指令，验证确定性mock与服务端权限不会执行它；真实LLM仍需单独评测。

`evaluate` 包含4个固定案例：有效调查、缺少标识、批次不存在、越权/注入请求。4/4通过只说明这几个固定规则成立，**不能写成“Agent真实准确率100%”**。mock不调用模型，没有供应商计费token；`usage.available=false`表示不存在模型usage数据。

## 7. 一致备份和恢复

```powershell
python -m factory_agent_lab backup
```

备份使用SQLite backup API取得包含已提交WAL事务的一致快照，再写入ZIP。完整教学快照也包含用于权限测试的private/draft/deleted合成知识行；它是由本机实验目录所有者操作的开发备份，不应照搬为按角色隔离的生产导出接口。生产资料须按数据域单独授权与备份。不要只复制运行中的 `factory.sqlite3`，也不要把旧WAL文件混入恢复目录。

恢复演练：先停止对目标目录的操作，保留原目录备份，将ZIP解压到一个新目录（例如 `restore_workspace`），然后运行：

```powershell
python -m factory_agent_lab --workspace restore_workspace init
python -m factory_agent_lab --workspace restore_workspace report
```

`init`补齐args示例，不覆盖已有数据库记录。验证记录数、工单内容和 `PRAGMA integrity_check`；配套测试已执行此类往返检查。演练只验证合成教学数据，不代表公司备份方案已经验收。

## 8. 可选DeepSeek调用

只有明确使用 `--backend deepseek` 才联网；默认mock不需要密钥。真实后端会将你输入的问题和命中的**合成业务工具结果**发送给DeepSeek。不要放入未获授权的真实公司资料。

在运行机器的受信进程环境中配置 `AOI_RAG_API_KEY`，可选 `AOI_RAG_MODEL`（默认deepseek-chat）。本包只接受官方HTTPS基地址 `https://api.deepseek.com` 或其 `/v1` 写法，禁止重定向和任意地址发送密钥。不要把密钥写入代码、题目答案、参数JSON或Git。

```powershell
python -m factory_agent_lab agent --question "ST-01工位B-002批次误报为什么升高" --backend deepseek
```

该适配器使用常见兼容消息/工具格式，最多4次模型请求、8次工具调用，单次超时不超过20秒、整体预算60秒、消息字符预算16000。字符预算不是精确token计费估计。供应商支持情况与价格可能改变；真实服务连接和费用未在交付测试中验证。

只记录供应商实际返回的usage；缺失标未知。最终JSON校验引用编号是否来自本次工具，但引用存在不等于结论受到证据支持，因此状态仍为 `review_required`，需要工程师审核。无证据为 `insufficient_evidence`，非法工具、结构异常或预算耗尽会阻止任务。不会将失败回答伪装为成功。

## 9. 到真实产品还缺什么

本包用于学习工具契约、证据链、状态、权限、审批、幂等和评测，不是完整生产级平台。实际落地还应补真实身份与租户隔离、消息幂等/Outbox、跨系统一致性、接口限流、密钥管理、数据保留策略、恢复演练、真实LLM金标准评估、Windows目标环境验证，以及真实视觉模型和现场样件验收。

当前工单提交与审计插入是两个本地提交，运行记录也未提供自动崩溃续跑；它们演示持久化和可核对日志，不能证明原子审计、跨系统事务或自动恢复已经完成。生产系统应将本地关键写入与审计同事务提交，跨系统操作另设可靠消息和结果核对。

mock路由是显式Python规则，没有自主规划能力。没有GPU测速、模型训练、图像分割或真实MES调用。授予Agent更多权限之前，先证明工具和工作流在失败条件下也能受控。
